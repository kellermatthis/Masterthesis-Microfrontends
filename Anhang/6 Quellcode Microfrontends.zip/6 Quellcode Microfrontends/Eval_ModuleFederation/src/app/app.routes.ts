import { Routes } from "@angular/router";
import { ContentComponent } from "./export/content/content.component";

export const APP_ROUTES: Routes = [
    { path: '', component: ContentComponent, pathMatch: 'full'}
  ];