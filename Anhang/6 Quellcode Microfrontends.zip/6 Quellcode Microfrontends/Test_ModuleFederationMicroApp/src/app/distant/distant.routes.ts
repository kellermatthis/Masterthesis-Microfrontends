import { Routes } from "@angular/router";
import { RemoteComponent } from "./remote/remote.component";

export const REMOTE_ROUTES: Routes = [
    {
      path: '',
      component: RemoteComponent
    }
  ];