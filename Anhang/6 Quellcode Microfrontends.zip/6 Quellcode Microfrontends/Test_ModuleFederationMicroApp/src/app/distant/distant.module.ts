import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { RemoteComponent } from './remote/remote.component';
import { REMOTE_ROUTES } from './distant.routes';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(REMOTE_ROUTES)
  ],
  declarations: [
    RemoteComponent
  ]
})
export class DistantModule { }
