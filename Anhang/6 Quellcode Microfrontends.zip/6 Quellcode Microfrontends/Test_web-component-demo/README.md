# WebComponentDemo

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 12.2.10.

## How to start

install nodejs and @angular/cli

run "npm i"

run "ng serve"
