const fs = require("fs-extra");

const rename = async () => {
  await fs.readdir('dist/DemoCounterApplication', async (error, files) => {
    let filename = files.filter(f => f.includes('main'))[0];
    await fs.rename('dist/DemoCounterApplication/' + filename, 'dist/DemoCounterApplication/simple-counter-bundle.js');
  });
};

rename();
