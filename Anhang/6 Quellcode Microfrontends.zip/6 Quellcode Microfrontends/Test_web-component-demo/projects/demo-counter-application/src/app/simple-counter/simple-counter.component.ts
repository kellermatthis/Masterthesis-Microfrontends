import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-simple-counter',
  templateUrl: './simple-counter.component.html',
  styleUrls: ['./simple-counter.component.css'],
  encapsulation: ViewEncapsulation.ShadowDom
})
export class SimpleCounterComponent implements OnInit {
  @Input() message: string = '';

  counter: number = 0;
  constructor() { }

  ngOnInit(): void {

  }


  increment(){
    this.counter++;
  }

  decrement(){
    if(this.counter===0){
      return;
    }

    this.counter--;
  }
}
