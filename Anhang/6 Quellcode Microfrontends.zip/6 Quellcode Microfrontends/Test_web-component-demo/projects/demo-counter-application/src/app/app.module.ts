import { DoBootstrap, Injector, NgModule } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { BrowserModule } from '@angular/platform-browser';
import { MatIconModule } from '@angular/material/icon'
import { MatButtonModule } from "@angular/material/button";
import { SimpleCounterComponent } from './simple-counter/simple-counter.component';

@NgModule({
  declarations: [
    SimpleCounterComponent
  ],
  imports: [
    BrowserModule,
    MatButtonModule,
    MatIconModule
  ],
  entryComponents: [
    SimpleCounterComponent
  ],
})
export class AppModule implements DoBootstrap {

  constructor(private injector: Injector) {
    const webComponent = createCustomElement(SimpleCounterComponent, {injector});
    customElements.define('simple-counter', webComponent);
  }

  ngDoBootstrap() {}
 }
