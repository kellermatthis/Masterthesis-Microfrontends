const fs = require("fs-extra");

const rename = async () => {
  await fs.readdir('dist/wetterapp', async (error, files) => {
    let filename = files.filter(f => f.includes('main'))[0];
    await fs.rename('dist/wetterapp/' + filename, 'dist/wetterapp/wetter-bundle.js');
  });
};

rename();
