# Wetter App Web Component

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 13.2.3.

## How to start

install nodejs and @angular/cli

run "npm i"

run "ng serve"