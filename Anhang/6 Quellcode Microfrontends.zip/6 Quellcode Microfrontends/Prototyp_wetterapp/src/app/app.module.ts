import { Injector, NgModule } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { BrowserModule } from '@angular/platform-browser';
import { WeatherComponent } from './weather/weather.component';

@NgModule({
  declarations: [
    WeatherComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: []
})
export class AppModule {
  constructor(private injector: Injector) {
    const webComponent = createCustomElement(WeatherComponent, {injector: this.injector});
    //avoid double registration errors
    if(!customElements.get('weather-component')){
      customElements.define('weather-component', webComponent);
    }
    
  }
 }
