import { Component, Input, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-weather',
  template: `
  <div class="wrapper">
    <h1>Wetter für {{location}}</h1>
    <div class="center">
        <div>
        <label>Heute: Sonnig, 20° </label><i class="far fa-sun"></i>
        </div>
        <div>
        <label>Morgen: Wolkig, 16° </label><i class="fas fa-smog"></i>
        </div>
    </div>
  </div>`,
  styles: ['.wrapper{width: 300px;margin: auto;}', '.center{display: inline;float: none;text-align: center;}', '@import https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class WeatherComponent{
  
  @Input() location: string = '';  

}
