const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const mf = require("@angular-architects/module-federation/webpack");
const share = mf.share;
const path = require("path");
const webpack = require('webpack');

const sharedMappings = new mf.SharedMappings();
sharedMappings.register(
  path.join(__dirname, 'tsconfig.json'),
  [/* mapped paths to share */]);

module.exports = {
  output: {
    publicPath: "http://localhost:4204/",
    uniqueName: "evalmfwc"
  },
  optimization: {
    // Only needed to bypass a temporary bug
    runtimeChunk: false
  },
  plugins: [
    new ModuleFederationPlugin({
        name: "evalmfwc",
        library: { type: "var", name: "evalmfwc" },
        filename: "remoteEntry.js",
        exposes: {
            './web-components': './src/bootstrap.ts',
        },        

        shared: share({
          //"@angular/core": { singleton: true, strictVersion: true, requiredVersion: 'auto' }, 
          "@angular/common": { singleton: true, strictVersion: true, requiredVersion: 'auto' }, 
          "@angular/common/http": { singleton: true, strictVersion: true, requiredVersion: 'auto' }, 
          "@angular/router": { singleton: true, strictVersion: true, requiredVersion: 'auto' },
          "@angular/material": { singleton: true, strictVersion: true, requiredVersion: 'auto' },
          "moment": { singleton: true, strictVersion: true, requiredVersion: 'auto' },
          "cheerio": { singleton: true, strictVersion: true, requiredVersion: 'auto' },
          "core-js": { singleton: true, strictVersion: true, requiredVersion: 'auto' },
          "jquery": { singleton: true, strictVersion: true, requiredVersion: 'auto' },
          "less": { singleton: true, strictVersion: true, requiredVersion: 'auto' },
          "bluebird": { singleton: true, strictVersion: true, requiredVersion: 'auto' },
          "autoprefixer": { singleton: true, strictVersion: true, requiredVersion: 'auto' },
  
          
          ...sharedMappings.getDescriptors()
        })
      })
  ],
};
