import { Injector, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ContentComponent } from './content/content.component';
import { createCustomElement } from '@angular/elements';

@NgModule({
  declarations: [
    ContentComponent
  ],
  imports: [
    BrowserModule,
    MatProgressBarModule
  ],
  bootstrap: []
})
export class AppModule{   
  constructor(private injector: Injector) {    
  }

  ngDoBootstrap() {
    const webComponent = createCustomElement(ContentComponent, {injector: this.injector});
    //avoid double registration errors
    if(!customElements.get('content-component-mf')){
      customElements.define('content-component-mf', webComponent);
    }
  }
  
}
