const fs = require("fs-extra");

const rename = async () => {
  await fs.readdir('dist/WebComponent', async (error, files) => {
    let filename = files.filter(f => f.includes('main'))[0];

    // butcher css into js component    
    const css = fs.readFileSync('dist/WebComponent/styles.css', 'utf8');
    const js = fs.readFileSync('dist/WebComponent/'+filename, 'utf8');
    let result = js.replace('],styles:[\'', '],styles:[\'' + css);
    result = result.replace(/\s+/g, ' ').trim(); // remove line breaks
    fs.writeFile('dist/WebComponent/'+filename, result, 'utf8');
    
    
    await fs.rename('dist/WebComponent/' + filename, 'dist/WebComponent/webcomponent.js');
  });
};

rename();