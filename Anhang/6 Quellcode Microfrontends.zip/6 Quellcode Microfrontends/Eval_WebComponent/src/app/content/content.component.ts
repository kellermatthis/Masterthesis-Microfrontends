import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import * as moment from 'moment';
import * as cheerio from 'cheerio';
import * as corejs from 'core-js';
import * as ngcore from '@angular/core';
import * as jquery from 'jquery';
import * as less from 'less';
import * as bluebird from 'bluebird';
import * as autoprefixer from 'autoprefixer';


@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css'],
  encapsulation: ViewEncapsulation.None,
  //encapsulation: ViewEncapsulation.ShadowDom //but then ngmat does not work locally...
})
export class ContentComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
    /**/
    console.log(moment);
    console.log(ngcore);
    console.log(jquery);
    console.log(cheerio);
    console.log(corejs);
    console.log(less);
    console.log(bluebird);
    console.log(autoprefixer);    
    
  }

}
