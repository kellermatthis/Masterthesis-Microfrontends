import { CUSTOM_ELEMENTS_SCHEMA, DoBootstrap, Injector, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ContentComponent } from './content/content.component';
import { createCustomElement } from '@angular/elements';

@NgModule({
  declarations: [
    ContentComponent
  ],
  imports: [
    BrowserModule,
    MatProgressBarModule
  ],
  entryComponents: [
    ContentComponent
  ],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule implements DoBootstrap{ 
  
  constructor(private injector: Injector) {
    
  }

  ngDoBootstrap() {
    const webComponent = createCustomElement(ContentComponent, {injector: this.injector});
    //avoid double registration errors
    if(!customElements.get('content-component')){
      customElements.define('content-component', webComponent);
    }
  }
}
