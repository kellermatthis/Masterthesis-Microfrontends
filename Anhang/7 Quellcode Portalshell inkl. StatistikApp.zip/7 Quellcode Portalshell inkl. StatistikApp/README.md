# Portalshell Demo

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 13.2.3.

## How to start

install nodejs and @angular/cli

run "npm i" command

run "ng serve" command

open a new command line in the same path

navigate to ./src/mfStatistic/ with "cd ./src/mfStatistic/" command

run there "npm i" command too

run there "ng serve" command too