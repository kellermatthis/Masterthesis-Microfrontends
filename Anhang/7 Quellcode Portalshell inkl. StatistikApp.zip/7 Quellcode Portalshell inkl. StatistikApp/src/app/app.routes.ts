import { loadRemoteModule } from '@angular-architects/module-federation';
import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { IframeComponent } from './iframe/iframe.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { PrototypComponent } from './prototyp/prototyp.component';
import { WebComponentInjectorComponent } from './web-component-injector/web-component-injector.component';
import { WebComponentComponent } from './web-component/web-component.component';
import { WrapperComponent } from './wrapper/wrapper.component';

const URL = 'http://localhost:4202/remoteEntry.js';
//const URL = 'https://mfmodulefederation.z16.web.core.windows.net/remoteEntry.js';

export const APP_ROUTES: Routes = [
    {
      path: '',
      component: HomeComponent,
      pathMatch: 'full'
    },
    {
      path: 'EvalIFrame',
      component: IframeComponent,
      pathMatch: 'full'
    },
    {
      path: 'EvalWC',
      component: WebComponentComponent,
      pathMatch: 'full'
    },
    {
      path: 'EvalMF', 
      loadChildren: () => loadRemoteModule({
        type: 'module',
        remoteEntry: URL,
        exposedModule: './Module'
      })
      .then(m => m.ExportModule)
    },
    {
      path: 'EvalMFWC',
      component: WrapperComponent,
      pathMatch: 'full', 
      data: { importName: 'evalwcmf', elementName: 'content-component-mf' }
    },
    {
      path: 'webcomponent',
      component: WebComponentInjectorComponent,
      pathMatch: 'full'
    },
    {
      path: 'Prototyp',
      component: PrototypComponent,
      pathMatch: 'full',
      children: [
        {
          path: '', 
          outlet: 'modulefederation',
          loadChildren: () => loadRemoteModule({
            type: 'module',
            remoteEntry: URL,
            exposedModule: './Module'
          })
          .then(m => m.ExportModule)
        } ]
    },
    {
      path: '**',
      component: NotfoundComponent
    }
  ];