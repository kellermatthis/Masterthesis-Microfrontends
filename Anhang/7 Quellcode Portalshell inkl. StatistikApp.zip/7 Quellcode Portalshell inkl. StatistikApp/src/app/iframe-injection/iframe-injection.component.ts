import { Component, Input, OnInit } from '@angular/core';
import * as $ from "jquery";

@Component({
  selector: 'iframe-injection',
  template: '<iframe id="iframeId" [height]="height" [width]="width"></iframe>'
})
export class IFrameInjectionComponent implements OnInit {

  @Input()
  url: string = '';
  @Input()
  height: string = '';
  @Input()
  width: string = '';

  ngOnInit(): void {
    $('#iframeId').attr('src', this.url);
  }
}
