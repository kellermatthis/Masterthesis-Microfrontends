import { Component, OnInit } from '@angular/core';
import { AuthService } from '@demo/auth-lib';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  user: string = '';
  constructor(private authService: AuthService) {
    this.authService.login('Matthis', null);
    this.user = authService.userName;
  }

  ngOnInit(): void {
  }
}
