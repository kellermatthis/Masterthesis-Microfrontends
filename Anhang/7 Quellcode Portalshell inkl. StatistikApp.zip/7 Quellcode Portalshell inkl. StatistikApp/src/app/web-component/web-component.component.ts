import { Component, ElementRef, OnInit } from '@angular/core';

@Component({
  selector: 'app-web-component',
  templateUrl: './web-component.component.html',
  styleUrls: ['./web-component.component.css']
})
export class WebComponentComponent implements OnInit {

  private element: HTMLElement;

  constructor(private wrapperElement: ElementRef) { }

  ngOnInit(): void {
    this.element = this.loadWCFromUrl(
      this.wrapperElement,
      'https://mfwebcomponent.blob.core.windows.net/webcomponent/webcomponent.js',
      //'https://mfwebcomponent.blob.core.windows.net/webcomponent/webcomponentmoment.js',
      //'https://mfwebcomponent.blob.core.windows.net/webcomponent/webcomponent_Eval_1.js',
      //'https://mfwebcomponent.blob.core.windows.net/webcomponent/webcomponent_Eval_3.js',
      //'https://mfwebcomponent.blob.core.windows.net/webcomponent/webcomponent_Eval_5.js',
      //'https://mfwebcomponent.blob.core.windows.net/webcomponent/webcomponent_Eval_8.js',
      'content-component'
    );
  }

  loadWCFromUrl(wrapper: ElementRef, hostingURL: string, htmlTagName: string) : HTMLElement {
    const wrapperElement: HTMLElement = wrapper.nativeElement;
    const shadow = wrapperElement.attachShadow({mode: 'open'});
    const script = document.createElement('script');
    script.src = hostingURL;

    const webComponent = document.createElement(htmlTagName);
    const webComponent2 = document.createElement(htmlTagName);

    script.onload = () => {
      shadow.appendChild(webComponent);
      shadow.appendChild(webComponent2);
    }

    shadow.appendChild(script);
    return webComponent;
  }
}
