import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, Injector, NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { RouterModule } from '@angular/router';
import { APP_ROUTES } from './app.routes';
import { SidenavComponent } from './sidenav/sidenav.component';
import { WebComponentInjectorComponent } from './web-component-injector/web-component-injector.component';
import { WebComponentComponent } from './web-component/web-component.component';
import { IframeComponent } from './iframe/iframe.component';
import { WrapperComponent } from './wrapper/wrapper.component';
import { PrototypComponent } from './prototyp/prototyp.component';
import { IFrameInjectionComponent } from './iframe-injection/iframe-injection.component';
import { AuthLibModule } from '@demo/auth-lib';

@NgModule({
  imports: [
    BrowserModule,
    AuthLibModule,
    RouterModule.forRoot(APP_ROUTES)
  ],
  declarations: [
    AppComponent,
    HomeComponent,
    NotfoundComponent,
    SidenavComponent,
    WebComponentInjectorComponent,
    WebComponentComponent,
    IframeComponent,
    WrapperComponent,
    PrototypComponent,
    IFrameInjectionComponent
  ],
  providers: [],
  bootstrap: [
    AppComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AppModule {
  //constructor(private injector: Injector) {}
 }
