import { Component, OnInit } from '@angular/core';
import { AuthService } from '@demo/auth-lib';

@Component({
  selector: 'app-prototyp',
  templateUrl: './prototyp.component.html',
  styleUrls: ['./prototyp.component.css']
})
export class PrototypComponent implements OnInit {

  constructor(private authService: AuthService) {
    this.authService.login('Matthis', null);
  }

  ngOnInit(): void {
  }
}
