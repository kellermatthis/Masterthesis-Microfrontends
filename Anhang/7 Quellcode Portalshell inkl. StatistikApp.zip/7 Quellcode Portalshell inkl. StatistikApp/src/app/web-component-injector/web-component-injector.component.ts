import { Component, ElementRef, Input, OnInit } from '@angular/core';

@Component({
  selector: 'web-component-injector',
  template: '',
})
export class WebComponentInjectorComponent implements OnInit {
  private element: HTMLElement;
  
  @Input() url: string = '';
  @Input() name: string = '';
  @Input() location: string = '';

  constructor(private wrapperElement: ElementRef) { }

  ngOnInit(): void {
    this.element = this.loadWCFromUrl(this.wrapperElement, this.url, this.name );
  }

  loadWCFromUrl(wrapper: ElementRef, hostingURL: string, htmlTagName: string) : HTMLElement {
    const wrapperElement: HTMLElement = wrapper.nativeElement;
    const shadow = wrapperElement.attachShadow({mode: 'open'});
    const script = document.createElement('script');
    script.src = hostingURL;

    const webComponent = document.createElement(htmlTagName);
    webComponent.setAttribute('location', this.location);

    script.onload = () => { shadow.appendChild(webComponent); }

    shadow.appendChild(script);
    return webComponent;
  }
}
