declare module 'microAppDemo/Module';
declare module 'evalmf/Module';
declare module 'evalmfwc/web-components';