import { Routes } from "@angular/router";
import { ContentComponent } from "./content/content.component";

export const REMOTE_ROUTES: Routes = [
    {
      path: '',
      component: ContentComponent
    }
  ];