import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { REMOTE_ROUTES } from './export.routes';
import { ContentComponent } from './content/content.component';
import { MatProgressBarModule } from '@angular/material/progress-bar';



@NgModule({
  declarations: [
    ContentComponent
  ],
  imports: [
    CommonModule,
    MatProgressBarModule,
    RouterModule.forChild(REMOTE_ROUTES)
  ]
})
export class ExportModule { }
