import { Component, OnInit } from '@angular/core';
import { AuthService } from '@demo/auth-lib';
import * as moment from 'moment';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
  now : any;
  random: number = 0;
  userCount: number = 0;
  userName = this.authService.userName;
  isAdmin: boolean = false; 

  constructor(private authService: AuthService) {
    this.now = moment().format('LLLL');
    this.random = Math.floor(Math.random() * (100 - 1) + 1);
    this.userCount = Math.floor(Math.random() * (1000 - 100) + 100);
  }

  ngOnInit(): void {
    this.isAdmin = this.userName === 'Matthis';
  }

}
